Here are some sample datasets that you can try your EM algorithm on to see if it works correctly. 
I had my epsilon value set to 0.001 (the threshold for convergence, i.e. when two consecutive loglihoods
have a difference < epsilon, we say that it has converged).

Note: We're not going to be too strict on the format of your output.

Tip: When choosing your initial means, one good way to choose them would be the lowest, median and highest values from your data set.